# LEER LOS DATOS
data<- read.csv(file.choose())
data2007 <- data[data["year"]==2007,]
# Modelo lineal generalizado
m <- glm(formula = lifeExp ~ log(gdpPercap) + continent,data = data2007)
summary(m)